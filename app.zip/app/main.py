from flask import Flask, redirect, url_for, render_template, request, session, flash
from flask_sqlalchemy import SQLAlchemy


app = Flask(__name__, static_folder='static')
app.config['SECRET_KEY'] = 'Python'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///crypto-db.sqlite'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)


class Crypto(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    price = db.Column(db.Float, nullable=False)


    def __str__(self):
        return f'Crypto name: {self.name}; Price: {self.price}'


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/add_crypto', methods=['GET', 'POST'])
def add_crypto():
    if request.method == 'POST':
        n = request.form['name']
        p = request.form['price']
        if n == '' or p == '':
            flash('შეავსეთ ყველა ველი', 'error')
        elif p is str:
            flash('ფასი უნდა იყოს რიცხვი', 'error')
        elif p < str(0):
            flash('ფასი უნდა იყოს დადებითი რიცხვი', 'error')
        else:
            c1 = Crypto(name=n, price=float(p))
            db.session.add(c1)
            db.session.commit()
            flash('მონაცემები წარმატებით დამატებულია', 'info')

    return render_template('add_crypto.html')


@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        u = request.form['username']
        p = request.form['password']
        if u == '' or p == '':
            flash('შეავსეთ ყველა ველი', 'error')
        else:
            session['username'] = u
            return redirect(url_for('index'))

    return render_template('login.html')


@app.route('/crypto')
def crypto():
    all_crypto = Crypto.query.all()
    return render_template('crypto.html', all_crypto=all_crypto)


@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))


if __name__ == "__main__":
    app.run(debug=True)
